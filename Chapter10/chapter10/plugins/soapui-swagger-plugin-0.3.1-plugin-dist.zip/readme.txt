SoapUI Swagger Plugin
-----------------------------

Adds Swagger-related functionality to SoapUI. See https://github.com/olensmar/soapui-swagger-plugin for more info.

Install by unzipping into SoapUI/bin folder.

Apache 2.0 Licensed.
